# Flux Content — One-Go Full Patch (2025-08-16)

This bundle wires **free APIs** and completes the missing features end‑to‑end.

## What’s in this patch
- **Research**: New Edge fn `research` (Tavily/Reddit/HN/Wikipedia) + page and store to drive ideas.
- **Batch Generation**: Already fixed; now consumes Research ideas if present.
- **Images**: Edge fn `generate-image` uses OpenAI (if present) → Lexica (no key) → Pexels (free key). Uploads to Storage when service role key is set.
- **Video**: Edge fn `generate-video` uses Pexels (free) or Pixabay (free). Requires one free key.
- **Content CRUD**: Edge `content` supports GET/PUT/DELETE. Client wired.
- **Brands**: Edge `brands` supports `?id=` lookup.
- **Scheduling**: Edge `schedule` for create/list + minimal client lib.
- **Invoker**: Robust GET/POST with query support.
- **Supabase Client**: Env-driven keys.
- **.env.example**: Updated for all free providers.

## Files to replace / add
- `src/integrations/supabase/client.ts`
- `src/lib/invoke.ts`
- `src/lib/content.ts`
- `src/lib/generate.ts`
- `src/lib/research.ts` **(new)**
- `src/lib/schedule.ts` **(new)**
- `src/store/research.ts` **(new)**
- `src/pages/ContentResearch.tsx` **(new)** — UI to run research and feed generation
- `supabase/functions/brands/index.ts`
- `supabase/functions/content/index.ts`
- `supabase/functions/research/index.ts` **(new)**
- `supabase/functions/generate-image/index.ts` (overhauled with free fallback)
- `supabase/functions/generate-video/index.ts` **(new)** (free providers)
- `supabase/functions/schedule/index.ts` **(new)**
- `.env.example`
- `PATCH_NOTES_FULL.md` (this file)

## Environment (copy this into your `.env` / project secrets)
Frontend `.env`:
```
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
TAVILY_API_KEY=            # optional
PEXELS_API_KEY=            # free; needed for best images & videos
PIXABAY_API_KEY=           # optional free fallback for video
```

Supabase Edge secrets:
```
supabase secrets set   OPENAI_API_KEY=          # optional   TAVILY_API_KEY=          # optional   PEXELS_API_KEY=...   PIXABAY_API_KEY=...   SUPABASE_SERVICE_ROLE_KEY=...
```

## Verify
1) **Brands** → create brand.  
2) **Research** → search → sources on → results appear.  
3) **Use for Generation** → pick count → generates captions/posts/images/videos.  
4) **Content** → items show; edit/save/delete works.  
5) **Schedule** → `createSchedule(contentId, brandId, ISO)` works; list via `listSchedules()`.  
6) **Storage** → images uploaded (if service role set); otherwise external URLs are kept.

